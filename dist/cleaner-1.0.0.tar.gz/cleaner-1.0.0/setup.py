from distutils.core import setup
setup(
    name= "cleaner",
    version = '1.0.0',
    py_modules = ['cleaner'],
    author='Akshat Garg',
    author_email='akshatgarg789@gmail.com'
)